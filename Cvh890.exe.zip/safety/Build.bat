@echo off
C:\mingw32\bin\windres.exe resource.rc -O coff -o resource.res
C:\mingw32\bin\g++.exe -O3 Main.cpp resource.res -o chv890-GDIOnly.exe -lwinmm -lgdi32 -lcomctl32 -lmsimg32 -mwindows -static -static-libgcc -static-libstdc++
pause
